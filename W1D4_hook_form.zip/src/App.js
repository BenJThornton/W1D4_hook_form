import logo from './logo.svg';
import UserForm from './components/UserForm'
import './App.css';

function App() {
  return (
    <div className="App-header">
      <div>
      <UserForm/>
      </div>
    </div>
  );
}

export default App;
