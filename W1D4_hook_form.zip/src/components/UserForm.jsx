import React, { useState } from  'react';
    
    
const UserForm = (props) => {
    const [firstname, setFirstname] = useState("");
    const [lastname, setLastname] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");  
    
    const createUser = (e) => {
        e.preventDefault();
        const newUser = { firstname, lastname, email, password };
        console.log("Welcome", newUser);
    };
    
    return(
        <div>
            <form onSubmit={ createUser }>
                <div>
                    <label>Firstname: </label> 
                    <input type="text" onChange={ (e) => setFirstname(e.target.value)} value={firstname} />
                </div>
                <div>
                    <label>Lastname: </label> 
                    <input type="text" onChange={ (e) => setLastname(e.target.value)} value={lastname} />
                </div>
                <div>
                    <label>Email Address: </label> 
                    <input type="text" onChange={ (e) => setEmail(e.target.value) } value={email} />
                </div>
                <div>
                    <label>Password: </label>
                    <input type="text" onChange={ (e) => setPassword(e.target.value) } value={password} />
                </div>
                <input type="submit" value="Create User" />
            </form>
            <div>
                <p>{firstname} {lastname}</p>
                <p>{email}</p>
                <p>{password}</p>
            </div>
        </div>
    );
};
    
export default UserForm;